
# ============================================================
# FAKE NEWS DETECTION SYSTEM (IDLE FRIENDLY VERSION)
# ============================================================

import re
import string
import pandas as pd
import nltk
from nltk.corpus import stopwords
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score

# Download NLTK data (only first time)
nltk.download('stopwords')

stop_words = set(stopwords.words('english'))

# ============================================================
# STEP 1: CREATE SMALL DATASET (No download needed)
# ============================================================

data = [
    ("Aliens landed on Earth yesterday", 0),
    ("Government releases new economic policy", 1),
    ("Drinking bleach cures all diseases", 0),
    ("Scientists discover new cancer treatment", 1),
    ("5G towers control human brain", 0),
    ("Stock market hits record high", 1),
    ("Man becomes invisible after eating magic fruit", 0),
    ("New education policy approved by parliament", 1),
]

df = pd.DataFrame(data, columns=["text", "label"])

# ============================================================
# STEP 2: TEXT CLEANING
# ============================================================

def clean_text(text):
    text = text.lower()
    text = re.sub(r"http\S+", "", text)
    text = text.translate(str.maketrans("", "", string.punctuation))
    words = text.split()
    words = [w for w in words if w not in stop_words]
    return " ".join(words)

df["clean_text"] = df["text"].apply(clean_text)

# ============================================================
# STEP 3: SPLIT DATA
# ============================================================

X_train, X_test, y_train, y_test = train_test_split(
    df["clean_text"], df["label"], test_size=0.2, random_state=42
)

# ============================================================
# STEP 4: TF-IDF + MODEL
# ============================================================

vectorizer = TfidfVectorizer()
X_train_vec = vectorizer.fit_transform(X_train)
X_test_vec = vectorizer.transform(X_test)

model = LogisticRegression()
model.fit(X_train_vec, y_train)

# ============================================================
# STEP 5: EVALUATION
# ============================================================

y_pred = model.predict(X_test_vec)
accuracy = accuracy_score(y_test, y_pred)

print("\n✅ Model Accuracy:", round(accuracy * 100, 2), "%")

# ============================================================
# STEP 6: PREDICTION FUNCTION
# ============================================================

def predict_news(text):
    cleaned = clean_text(text)
    vector = vectorizer.transform([cleaned])
    result = model.predict(vector)[0]

    if result == 1:
        print("\n📰 REAL NEWS")
    else:
        print("\n🚨 FAKE NEWS")

# ============================================================
# STEP 7: TEST PREDICTIONS
# ============================================================

print("\n--- Sample Predictions ---")
predict_news("Scientists found a new vaccine")
predict_news("Aliens are controlling the government")

# ============================================================
# STEP 8: USER INPUT
# ============================================================

while True:
    user = input("\nEnter news (or type quit): ")
    if user.lower() == "quit":
        break
    predict_news(user)
